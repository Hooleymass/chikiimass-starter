export const Background = () => {
  return (
    <div className="background">
      <div className="blur" />
      <div className="gradient" />
    </div>
  )
}
