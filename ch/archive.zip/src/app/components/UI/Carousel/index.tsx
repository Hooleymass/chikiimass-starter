import React from 'react'

export const Carousel = () => {
  return (
    <div>Carousel</div>
  )
}
