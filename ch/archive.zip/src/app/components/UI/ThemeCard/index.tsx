import React from 'react'

export const ThemeCard = () => {
  return (
    <div>ThemeCard</div>
  )
}
