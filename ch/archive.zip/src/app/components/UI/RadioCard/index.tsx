import React from 'react'

export const RadioCard = () => {
  return (
    <div>RadioCard</div>
  )
}
