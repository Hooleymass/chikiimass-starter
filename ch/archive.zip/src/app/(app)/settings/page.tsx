
const page = () => {
    return (
        <div>
            <p>Settings</p>
        </div>
    )
}

export default page;