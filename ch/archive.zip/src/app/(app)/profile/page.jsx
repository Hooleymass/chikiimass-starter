import { SampleComponent } from '@/components/SampleComponent'


const page = () => {
    return (
        <SampleComponent />
    )
}

export default page