import { Posts } from '@/components/Posts';

const page = () => {
  return (
    <div className='text-lg text-indigo-500 italic font-sans'>
      <Posts />
    </div>
  )
}

export default page